# 💎 AuTron 4 Series: The Overhaul Changelog (March 12, 2026)

### 📥 HOW TO INSTALL & RUN (READ FIRST)
To use any of the AuTron models, you must follow these steps:

1.  **Install Ollama**: Download from [ollama.com](https://ollama.com/).
2.  **Download AI Brains**: Run these commands in your terminal to get the required models:
    *   `ollama pull sam860/LFM2:1.2b` (Primary Brain)
    *   `ollama pull sam860/LFM2:350m` (Speed Brain used for /fast mode)
    *   `ollama pull sam860/LFM2:2.6b` (Elite Brain used for Prism synthesis)
    *   `ollama pull sam860/LFM2:700m` (Base Brain used for Nano/Leaf)
3.  **Install Requirements**: Run `pip install -r requirements.txt` (or `pip install ollama duckduckgo-search rich`).
4.  **Run Any Model**: Execute `python autron-ultra.py` (or any other model file).

---

### 🌐 NEW MODEL DEBUT: AuTron 4o (Omni)
*We are officially introducing the **Omni** model in this version—the dedicated Web Research specialist of the AuTron family.*

*   **Initial Launch**: Built from the ground up as a search-native agent to handle real-time data synthesis.
*   **Domain-Agnostic Fact Extraction**: Features a universal pattern-matching engine that extracts financial figures, news, dates, and technical percentages across any topic.
*   **Authority-First Search Engine**: Implementation of source prioritization—Omni hunts for facts on trusted domains (Reuters, NASA, Wikipedia, GitHub) before general results.
*   **Async Logic Transformation**: Transitioned to a fully asynchronous (`async/await`) backend for non-blocking, multi-threaded web research.
*   **Perplexity-Style Synthesis**: Strict journalistic output rules that prioritize direct, definitive answers over link-dumping.

---

### 🧠 Model PERSONALITY & BEHAVIOR
*   **Tiered Role-Play**: Rewrote the core identity logic for all scripts (`ultra.py` through `leaf.py`). Models no longer share a single system prompt.
*   **Constraint Tuning**: Unique behavioral rules for each tier (e.g., **Ultra** strategy depth vs. **Leaf** extreme brevity).
*   **Tone Customization**: Injected model-specific tone instructions (e.g., **Prism** creative problem-solving; **Neo** adaptive user-energy mirroring).

### 📜 SYSTEM PROMPT & REASONING
*   **Prompt Compression**: Ported and compressed 100KB+ of industry-standard reasoning logic into a lightweight XML format optimized for local parameter models.
*   **Multi-Brain Synthesis Fix**: Refactored the synthesis logic in `ultra.py` and `prism.py`. Updated merging models to **v1.6B/v2.6B** and added strict constraints to eliminate robotic meta-talk ("Insight 1 says...").

### 🛠️ CORE SYSTEM & UI FIXES
*   **Byte-Level Emoji Restoration**: Project-wide cleanup of corrupted UTF-8 sequences ("Mojibake"). Restored all UI elements (rockets, icons, trophies) to crisp Unicode across all 6 model scripts.
*   **Web Server Dynamic Routing**: Updated `autron-web-server.py` to dynamically inject correct tier-specific prompts based on the model requested via API.

---
--AuTron Team
