# 🏆 AuTron 4 Series: Terminal AI Suite

Welcome to the official terminal release of the **AuTron 4 Series**. This repository contains the standalone Python implementations of the AuTron AI family, optimized for local execution via **Ollama**.

---

### 📦 Prerequisites

Before running any AuTron model, you must have the following installed:

1.  **Ollama**: [Download here](https://ollama.com/)
2.  **LFM2 Models**: AuTron uses the `sam860/LFM2` model library. Run the following command to prepare the default brain:
    ```bash
    ollama pull sam860/LFM2:1.2b
    ollama pull sam860/LFM2:350m
    ```
    *(Note: For Ultra/Prism, pulling the 2.6b and 1.6b versions is recommended for best results.)*

3.  **Python 3.8+**: Ensure you have Python installed on your system.

---

### 🚀 Installation

Install the required Python dependencies using pip:

```bash
pip install -r requirements.txt
```

*(Or manually: `pip install ollama duckduckgo-search rich`)*

---

### 💬 How to Run

Each file is a standalone terminal application. Simply run the python script for the model you wish to use:

*   **Ultra (Flagship)**: `python autron-ultra.py`
*   **Omni (Real-time Search)**: `python autron-omni.py`
*   **Prism (Creative Elite)**: `python autron-prism.py`
*   **Neo (Adaptive Daily)**: `python autron-neo.py`
*   **Nano (Efficient Standard)**: `python autron-nano.py`
*   **Leaf (Instant Speed)**: `python autron-leaf.py`

---

### 🛠️ Commands
Once inside the AI terminal, you can use several built-in commands:
*   `/help` - View available modes and commands.
*   `/mode <name>` - Switch between intelligence tiers (fast, think, pro, ultra).
*   `/clear` - Reset your session history.
*   `/exit` - Shutdown the AI.

---
--AuTron Team
